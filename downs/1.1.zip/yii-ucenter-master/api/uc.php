<?php
/**
 * Created by JetBrains PhpStorm.
 * User: weijie
 * Date: 13-2-19
 * Time: 上午10:06
 * File: uc.php
 * To change this template use File | Settings | File Templates.
 */
include_once(dirname(__FILE__).'/../protected/extensions/ucenter/api/uc.php');