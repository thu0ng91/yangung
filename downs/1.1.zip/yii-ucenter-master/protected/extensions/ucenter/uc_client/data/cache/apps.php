<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZX',
    'name' => 'Discuz! Board',
    'url' => 'http://www.88jianshen.com.zwj',
    'ip' => '127.0.0.1',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  6 => 
  array (
    'appid' => '6',
    'type' => 'OTHER',
    'name' => 'yii_ucenter',
    'url' => 'http://yii-ucenter.zwj',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  7 => 
  array (
    'appid' => '7',
    'type' => 'OTHER',
    'name' => '88门户2',
    'url' => 'http://www2.88jianshen.com.zwj',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  8 => 
  array (
    'appid' => '8',
    'type' => 'OTHER',
    'name' => 'yii_portal',
    'url' => 'http://www.88jianshen.com.zwj/yii_portal',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'synlogin' => '1',
    'extra' => 
    array (
      'apppath' => '',
      'extraurl' => '			',
    ),
    'recvnote' => '1',
  ),
  'UC_API' => 'http://www.88jianshen.com.zwj/uc_server',
);
