<?php
/**
 * Created by JetBrains PhpStorm.
 * User: weijie
 * Date: 13-2-23
 * Time: 上午10:02
 * File: msg.php
 * To change this template use File | Settings | File Templates.
 */?>
<h1><?php /* @var string $msg*/echo $msg;?></h1>
    <div><?php /* @var string $moremsg*/echo $moremsg;?></div>
    <?php /* @var string $code*/ echo $code;?>
<script type="text/javascript">
    setTimeout("window.location.href='index.php'",3000)
</script>